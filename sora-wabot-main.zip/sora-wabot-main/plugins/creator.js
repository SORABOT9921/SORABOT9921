let handler = function (m) {
  this.sendContact(m.chat, '6281290489712', 'SORAA', m)
  //plsss do not change this, jika mau add boleh tapi jangan rubah
  this.sendContact(m.chat, '6281290489712', 'SORAA :)', m)
}
handler.help = ['owner', 'creator']
handler.tags = ['info']

handler.command = /^(owner|creator)$/i

module.exports = handler
